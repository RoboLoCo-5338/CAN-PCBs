Images created from http://oshpark.com/ by uploading the CAMOutputs.zip which contains the CAM files. 

CAM files exported from Eagle 9.6.2